# Practice Exercises



* [Chapter 4: First lines of code](ch04_first_lines/readme.md)
* [Chapter 5: Interactive code](ch05_interactive_code/readme.md)
* [Chapter 6: Functions](ch06-organizing-code-with-functions/readme.md)
* [Chapter 7: Data structures](ch07_data_structures/readme.md)
* [Chapter 8: Problem solving](ch08_problem_solving/readme.md)
* [Chapter 9: Working with files](ch09_working_with_files/readme.md)
* [Chapter 10: External libraries](ch10_external_libraries/readme.md)
* [Chapter 11: Error handling](ch11-error-handling/readme.md)

